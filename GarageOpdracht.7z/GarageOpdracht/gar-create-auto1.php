<html>
<head>
    <title>gar-create-auto1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<style> .backgroundimg {position: fixed;}</style>
<body>

<div class="backgroundimg">
    <div class="menu">
        <h1>garage create auto 1</h1>
        <p>dit formulier wordt gebruikt om autogegevens in te voeren</p>
        <form action="gar-create-auto2.php" method="post">
            autokenteken: <input type="text" name="autokentekenvak"> <br/>
            automerk: <input type="text" name="automerkvak"> <br/>
            autokmstand: <input type="text" name="autokmstandvak"> <br/>
            klantid: <input type="text" name="klantidvak"> <br/>
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>
