<html>
<head>
    <title>gar-delete-auto1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage delete auto 1</h1>
        <p>
            dit formulier zoekt een auto op uit de tabel auto van de databse garage om hem te kunnen verwijderen
        </p>
        <form action="gar-delete-auto2.php" method="post">
            welke auto wilt u verwijderen?
            <input type="text" name="klantidvak">
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>