<html>
<head>
    <title>gar-update-klant1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage update klant 1</h1>
        <p>
            dit formulier wordt gebruikt om klangegevens te weizigen
        </p>
        <form action="gar-update-klant2.php" method="post">
            welk klantid wilt u weizigen?
            <input type="text" name="klantidvak"> <br/>
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>