<html>
<head>
    <title>gar-update-auto1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage update auto 1</h1>
        <p>dit formulier wordt gebruikt om autogegevns te wijzigen</p>
        <form action="gar-update-auto2.php" method="post">
            welke auto wilt u wijzigen? (autokenteken invoeren AUB)
            <input type="text" name="autokentekenvak"> <br/>
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>