<html>
<head>
    <title>gar-zoek-klant1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage zoek klant</h1>
        <p>dit formulier zoekt een klant uit de tabel klanten van database garage.</p>
        <form action="gar-zoek-klant2.php" method="post">
            welke klantid zoek u?
            <input type="text" name="klantidvak"> <br/>
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>