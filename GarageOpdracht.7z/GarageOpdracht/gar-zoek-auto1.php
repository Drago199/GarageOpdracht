<html>
<head>
    <title>gar-zoek-auto1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage zoek op autokenteken</h1>
        <p>dit formi=ulier zoekt een auto op uit de tabel auto van de database garage</p>
        <form action="gar-zoek-auto2.php" method="post">
            welk kenteken zoekt u?
            <input type="text" name="kentekenvak"> <br/>
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>