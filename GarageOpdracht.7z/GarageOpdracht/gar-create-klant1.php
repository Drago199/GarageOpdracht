<html>
<head>
    <title>gar-create-klant1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg"></div>
    <div class="menu2">
        <h1>garage create klant 1</h1>
        <p>dit formulier wordt gebruikt om klantgegevens in te voeren</p>
        <form action="gar-create-klant2.php" method="post">
            klantnaam: <input type="text" name="klantnaamvak"> <br/>
            klantadres: <input type="text" name="klantadresvak"> <br/>
            klantpostcode: <input type="text" name="klantpostcodevak"> <br/>
            klantplaats: <input type="text" name="klantplaatsvak"> <br/>
            <input type="submit">
        </form>

</div>
</body>
</html>


