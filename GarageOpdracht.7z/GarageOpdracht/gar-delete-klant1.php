<html>
<head>
    <title>gar-delete-klant1</title>
    <link href="style/css/main.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
</head>
<body>
<div class="backgroundimg">
    <div class="menu">
        <h1>garage delete klant 1</h1>
        <p>
            dit formulier zoekt een klant op uit de tabel klanten van de databse garage om hem te kunnen verwijderen
        </p>
        <form action="gar-delete-klant2.php" method="post">
            welk klantid wilt u verwijderen?
            <input type="text" name="klantidvak">
            <input type="submit">
        </form>
    </div>
</div>
</body>
</html>